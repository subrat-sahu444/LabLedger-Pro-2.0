import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import { useSQLiteContext } from "expo-sqlite";
import { createEntry } from "@/src/db/entries";
import { Screen, styles } from "@/src/ui";

const subjects = ["Chemistry", "Physics", "Biology", "Environmental", "Other"];
export default function NewEntryScreen() {
  const db = useSQLiteContext(); const router = useRouter();
  const [title, setTitle] = useState(""); const [subject, setSubject] = useState("Chemistry");
  const [objective, setObjective] = useState(""); const [method, setMethod] = useState("");
  const [observations, setObservations] = useState(""); const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (title.trim().length < 3) { Alert.alert("Add a title", "Use at least 3 characters."); return; }
    setBusy(true);
    try { await createEntry(db, { title: title.trim(), subject, objective, method, observations, result }); router.back(); }
    catch { Alert.alert("Could not save", "Please try again."); } finally { setBusy(false); }
  };
  const field = (label: string, value: string, setter: (v: string) => void, placeholder: string, multiline = true) => <>
    <Text style={styles.fieldLabel}>{label}</Text>
    <TextInput value={value} onChangeText={setter} multiline={multiline} placeholder={placeholder} placeholderTextColor="#718096" style={[styles.input, multiline && styles.multiline]} maxLength={4000}/>
  </>;
  return <Screen><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.eyebrow}>NEW RECORD · STORED ON THIS DEVICE</Text><Text style={styles.formHeading}>Capture the details.</Text>
      <Text style={styles.fieldLabel}>Experiment title *</Text>
      <TextInput value={title} onChangeText={setTitle} placeholder="e.g. Acid-base titration" placeholderTextColor="#718096" style={styles.input} maxLength={100}/>
      <Text style={styles.fieldLabel}>Subject</Text><View style={styles.chips}>{subjects.map(s => <Pressable key={s} onPress={() => setSubject(s)} style={[styles.chip, subject === s && styles.chipSelected]}><Text style={[styles.chipText, subject === s && styles.chipTextSelected]}>{s}</Text></Pressable>)}</View>
      {field("Objective", objective, setObjective, "What are you investigating?")}
      {field("Materials & method", method, setMethod, "Record setup and procedure...")}
      {field("Observations", observations, setObservations, "Record measurements and units...")}
      {field("Result & conclusion", result, setResult, "Summarize the result and sources of error...")}
      <Pressable disabled={busy} onPress={save} style={[styles.primaryButton, busy && { opacity: 0.6 }]}><Text style={styles.primaryButtonText}>{busy ? "Saving..." : "Save experiment"}</Text></Pressable>
    </ScrollView></KeyboardAvoidingView></Screen>;
}