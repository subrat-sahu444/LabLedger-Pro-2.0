import { useCallback, useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, useFocusEffect, useRouter } from "expo-router";
import { useSQLiteContext } from "expo-sqlite";
import { Entry, getEntry, setEntryStatus, deleteEntry, addMeasurement, listMeasurements, Measurement } from "@/src/db/entries";
import { exportEntryPdf } from "@/src/services/pdf";
import { MeasurementChart } from "@/src/components/MeasurementChart";
import { Screen, styles } from "@/src/ui";

export default function EntryScreen() {
  const { id } = useLocalSearchParams<{ id: string }>(); const db = useSQLiteContext(); const router = useRouter();
  const [entry, setEntry] = useState<Entry | null>(null); const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [label, setLabel] = useState("Reading"); const [value, setValue] = useState(""); const [unit, setUnit] = useState("");
  const load = useCallback(async () => { const n = Number(id); setEntry(await getEntry(db, n)); setMeasurements(await listMeasurements(db, n)); }, [db, id]);
  useFocusEffect(useCallback(() => { void load(); }, [load]));
  const remove = () => Alert.alert("Delete experiment?", "This permanently removes this local entry.", [
    { text: "Cancel", style: "cancel" }, { text: "Delete", style: "destructive", onPress: async () => { await deleteEntry(db, Number(id)); router.back(); } }
  ]);
  const saveMeasurement = async () => {
    const n = Number(value);
    if (!label.trim() || !value.trim() || !Number.isFinite(n)) { Alert.alert("Check measurement", "Enter a label and a valid number."); return; }
    await addMeasurement(db, Number(id), label.trim(), n, unit.trim()); setValue(""); await load();
  };
  if (!entry) return <Screen><Text style={styles.subtle}>Loading entry…</Text></Screen>;
  const sections = [["Objective", entry.objective], ["Materials & method", entry.method], ["Observations", entry.observations], ["Result & conclusion", entry.result]];
  return <Screen><ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
    <Text style={styles.eyebrow}>{entry.subject.toUpperCase()} · {new Date(entry.createdAt).toLocaleString()}</Text>
    <Text style={styles.detailTitle}>{entry.title}</Text>
    <View style={styles.detailActions}>
      <Pressable onPress={async () => { await setEntryStatus(db, entry.id, entry.status === "completed" ? "draft" : "completed"); await load(); }} style={styles.outlineButton}><Text style={styles.outlineButtonText}>{entry.status === "completed" ? "Mark as draft" : "Mark completed"}</Text></Pressable>
      <Pressable onPress={() => exportEntryPdf(entry, measurements)} style={styles.outlineButton}><Text style={styles.outlineButtonText}>Export PDF</Text></Pressable>
      <Pressable onPress={remove} style={styles.deleteButton}><Text style={styles.deleteText}>Delete</Text></Pressable>
    </View>
    {sections.map(([heading, body]) => <View key={heading} style={styles.detailSection}><Text style={styles.fieldLabel}>{heading}</Text><Text style={styles.detailBody}>{body?.trim() || "Not recorded."}</Text></View>)}
    <Text style={styles.sectionTitle}>Scientific measurements</Text>
    <Text style={styles.subtle}>Add numeric readings to create a simple trend chart.</Text>
    <View style={styles.measureForm}>
      <TextInput value={label} onChangeText={setLabel} placeholder="Label" placeholderTextColor="#718096" style={[styles.input, { flex: 2 }]}/>
      <TextInput value={value} onChangeText={setValue} keyboardType="decimal-pad" placeholder="Value" placeholderTextColor="#718096" style={[styles.input, { flex: 1 }]}/>
      <TextInput value={unit} onChangeText={setUnit} placeholder="Unit" placeholderTextColor="#718096" style={[styles.input, { flex: 1 }]}/>
    </View>
    <Pressable onPress={saveMeasurement} style={styles.primaryButton}><Text style={styles.primaryButtonText}>Add measurement</Text></Pressable>
    {measurements.length > 0 ? <MeasurementChart measurements={measurements}/> : <Text style={styles.emptyText}>No numeric readings yet.</Text>}
    <Text style={styles.privacyNote}>Private by default · Stored locally on this device.</Text>
  </ScrollView></Screen>;
}