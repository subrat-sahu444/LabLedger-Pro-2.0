import { useState } from "react";
import { Alert, Pressable, Text, TextInput, View } from "react-native";
import { useSQLiteContext } from "expo-sqlite";
import { Screen, styles } from "@/src/ui";
import { createClientIfConfigured, cloudSignIn, cloudSignUp, uploadBackup, downloadBackup } from "@/src/services/cloud";
import { listEntries, restoreEntries } from "@/src/db/entries";

export default function BackupScreen() {
  const db = useSQLiteContext();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [message, setMessage] = useState("Cloud backup is optional. Your local notebook works without an account.");
  const [busy, setBusy] = useState(false);
  const configured = Boolean(createClientIfConfigured());
  const run = async (action: "signup" | "signin" | "upload" | "download") => {
    setBusy(true);
    try {
      if (action === "signup") await cloudSignUp(email.trim(), password);
      if (action === "signin") await cloudSignIn(email.trim(), password);
      if (action === "upload") await uploadBackup(await listEntries(db));
      if (action === "download") {
        const rows = await downloadBackup();
        await restoreEntries(db, rows);
      }
      setMessage(action === "upload" ? "Backup uploaded successfully." : action === "download" ? "Cloud backup restored to this device." : "Account action completed. Check your email if confirmation is enabled.");
    } catch (e) { setMessage(e instanceof Error ? e.message : "Cloud backup failed."); }
    finally { setBusy(false); }
  };
  return <Screen>
    <Text style={styles.eyebrow}>OPTIONAL · ACCOUNT-BASED BACKUP</Text>
    <Text style={styles.formHeading}>Your data, backed up.</Text>
    <Text style={styles.detailBody}>Sign in to your own Supabase account to upload or restore your experiment records. Cloud backup requires internet. Never share your password or Supabase service-role key.</Text>
    {!configured && <Text style={styles.warning}>Cloud service is not configured yet. Add the two EXPO_PUBLIC_SUPABASE values from your Supabase project, then restart Expo.</Text>}
    <Text style={styles.fieldLabel}>Email</Text>
    <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="you@example.com" placeholderTextColor="#718096" style={styles.input}/>
    <Text style={styles.fieldLabel}>Password</Text>
    <TextInput value={password} onChangeText={setPassword} secureTextEntry placeholder="At least 8 characters" placeholderTextColor="#718096" style={styles.input}/>
    <Pressable disabled={!configured || busy} onPress={() => run("signup")} style={styles.outlineButton}><Text style={styles.outlineButtonText}>Create account</Text></Pressable>
    <Pressable disabled={!configured || busy} onPress={() => run("signin")} style={styles.outlineButton}><Text style={styles.outlineButtonText}>Sign in</Text></Pressable>
    <View style={styles.divider}/>
    <Pressable disabled={!configured || busy} onPress={() => run("upload")} style={styles.primaryButton}><Text style={styles.primaryButtonText}>{busy ? "Working..." : "Back up this device"}</Text></Pressable>
    <Pressable disabled={!configured || busy} onPress={() => Alert.alert("Restore backup?", "Restoring replaces this device's current experiment list. Continue?", [{ text: "Cancel", style: "cancel" }, { text: "Restore", style: "destructive", onPress: () => { void run("download"); } }])} style={styles.outlineButton}><Text style={styles.outlineButtonText}>Restore from cloud</Text></Pressable>
    <Text style={styles.statusMessage}>{message}</Text>
  </Screen>;
}