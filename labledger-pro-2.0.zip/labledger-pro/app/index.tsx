import { useCallback, useMemo, useState } from "react";
import { FlatList, Pressable, Text, TextInput, View } from "react-native";
import { Link, useFocusEffect, useRouter } from "expo-router";
import { useSQLiteContext } from "expo-sqlite";
import { Ionicons } from "@expo/vector-icons";
import { Entry, listEntries } from "@/src/db/entries";
import { Card, EmptyState, Screen, SectionTitle, styles } from "@/src/ui";

export default function HomeScreen() {
  const db = useSQLiteContext();
  const router = useRouter();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [query, setQuery] = useState("");
  const [subject, setSubject] = useState("All");

  const load = useCallback(async () => setEntries(await listEntries(db)), [db]);
  useFocusEffect(useCallback(() => { void load(); }, [load]));

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return entries.filter(e => {
      const matchesSubject = subject === "All" || e.subject === subject;
      const searchable = [e.title, e.subject, e.objective, e.method, e.observations, e.result].join(" ").toLowerCase();
      return matchesSubject && (!q || searchable.includes(q));
    });
  }, [entries, query, subject]);

  const subjects = ["All", "Chemistry", "Physics", "Biology", "Environmental", "Other"];

  return (
    <Screen>
      <View style={styles.topline}>
        <View>
          <Text style={styles.eyebrow}>YOUR PERSONAL SCIENCE WORKSPACE</Text>
          <Text style={styles.hero}>Lab<Text style={{ color: "#55D6BE" }}>Ledger</Text></Text>
          <Text style={styles.subtle}>Observe carefully. Record everything.</Text>
        </View>
        <View style={styles.avatar}><Ionicons name="flask" size={23} color="#55D6BE" /></View>
      </View>
      <View style={styles.statsRow}>
        <Card style={styles.statCard}><Text style={styles.statNumber}>{entries.length}</Text><Text style={styles.statLabel}>EXPERIMENTS</Text></Card>
        <Card style={styles.statCard}><Text style={styles.statNumber}>{entries.filter(e => e.status === "completed").length}</Text><Text style={styles.statLabel}>COMPLETED</Text></Card>
      </View>
      <View style={styles.actionRow}>
        <Link href="/backup" asChild><Pressable style={styles.secondaryAction}><Ionicons name="cloud-outline" color="#8EF0DC" size={17}/><Text style={styles.secondaryActionText}>Backup</Text></Pressable></Link>
        <Link href="/new-entry" asChild><Pressable style={styles.smallAction}><Ionicons name="add" size={17} color="#08131D" /><Text style={styles.smallActionText}>New entry</Text></Pressable></Link>
      </View>
      <TextInput value={query} onChangeText={setQuery} placeholder="Search title, method, observations..." placeholderTextColor="#718096" style={styles.searchInput} clearButtonMode="while-editing" />
      <View style={styles.chips}>
        {subjects.map(s => <Pressable key={s} onPress={() => setSubject(s)} style={[styles.chip, subject === s && styles.chipSelected]}><Text style={[styles.chipText, subject === s && styles.chipTextSelected]}>{s}</Text></Pressable>)}
      </View>
      <View style={styles.sectionRow}><SectionTitle>{query || subject !== "All" ? "Search results" : "Recent entries"}</SectionTitle><Text style={styles.resultCount}>{filtered.length} found</Text></View>
      <FlatList
        data={filtered} keyExtractor={item => String(item.id)}
        contentContainerStyle={{ paddingBottom: 34, flexGrow: 1 }}
        ListEmptyComponent={<EmptyState onCreate={() => router.push("/new-entry")} />}
        renderItem={({ item }) => (
          <Link href={{ pathname: "/entry/[id]", params: { id: item.id } }} asChild>
            <Pressable><Card style={styles.entryCard}>
              <View style={styles.entryTop}><Text style={styles.category}>{item.subject.toUpperCase()}</Text><View style={[styles.status, item.status === "completed" ? styles.statusDone : styles.statusDraft]}><Text style={styles.statusText}>{item.status}</Text></View></View>
              <Text style={styles.entryTitle}>{item.title}</Text>
              <Text numberOfLines={2} style={styles.entrySummary}>{item.objective || "No objective added yet."}</Text>
              <View style={styles.entryBottom}><Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString()}</Text><Ionicons name="arrow-forward" size={16} color="#55D6BE" /></View>
            </Card></Pressable>
          </Link>
        )}
      />
    </Screen>
  );
}