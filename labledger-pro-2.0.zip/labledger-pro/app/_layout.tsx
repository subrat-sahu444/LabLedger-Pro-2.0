import { Stack } from "expo-router";
import { SQLiteProvider } from "expo-sqlite";
import { StatusBar } from "expo-status-bar";
import { initializeDatabase } from "@/src/db/database";

export default function RootLayout() {
  return (
    <SQLiteProvider databaseName="labledger.db" onInit={initializeDatabase}>
      <StatusBar style="light" />
      <Stack screenOptions={{
        headerStyle: { backgroundColor: "#101827" },
        headerTintColor: "#F5F7FB",
        contentStyle: { backgroundColor: "#0B1220" },
        headerShadowVisible: false
      }}>
        <Stack.Screen name="index" options={{ title: "LabLedger Pro", headerShown: false }} />
        <Stack.Screen name="new-entry" options={{ title: "New lab entry", presentation: "modal" }} />
        <Stack.Screen name="entry/[id]" options={{ title: "Experiment" }} />
        <Stack.Screen name="backup" options={{ title: "Cloud backup" }} />
      </Stack>
    </SQLiteProvider>
  );
}