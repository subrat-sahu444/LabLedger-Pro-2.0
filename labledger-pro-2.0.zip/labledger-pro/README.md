# 🧪 LabLedger Pro 2.0

**An offline-first mobile laboratory notebook.** Capture experiments, record numerical readings, visualize trends, export PDF reports, and optionally back up your notebook to a private Supabase account.

![Expo](https://img.shields.io/badge/Expo-SDK%2054-4630EB)
![TypeScript](https://img.shields.io/badge/TypeScript-strict-3178C6)
![Platform](https://img.shields.io/badge/platform-Android%20%7C%20iOS-55D6BE)
![License](https://img.shields.io/badge/license-MIT-green)

## Features

- Create, browse, and organize experiments by subject
- Full-text-style local search across title, subject, objective, method, observations, and result
- Add numerical measurements with labels and units
- Visualize measurement trends in a line chart
- Generate and share PDF experiment reports
- Mark experiments as draft or completed
- Offline-first SQLite database
- Optional authenticated cloud backup with Supabase Row Level Security
- Automated validation tests

## Tech stack

React Native, Expo SDK 54, Expo Router, TypeScript, Expo SQLite, React Native SVG, Expo Print, Expo Sharing, Supabase JS, Vitest.

## Windows setup

### Requirements
- Windows 10/11
- Node.js LTS (install from https://nodejs.org/)
- Git (https://git-scm.com/)
- Android phone with Expo Go, or Android Studio emulator

### Install dependencies

```powershell
# Extract the project, then open PowerShell in its folder
cd E:\LabLedger-Pro

npm.cmd install
npx.cmd expo install --fix
```

### Run on your phone

Install Expo Go from the Play Store. Connect phone and PC to the same Wi-Fi, then:

```powershell
npx.cmd expo start
```

Scan the QR code with Expo Go. If LAN discovery fails, try:

```powershell
npx.cmd expo start --tunnel
```

### Run checks

```powershell
npm.cmd run typecheck
npm.cmd test
```

## Optional cloud backup setup

Cloud backup is disabled until you configure Supabase.

1. Create a project at https://supabase.com/.
2. In Supabase Dashboard, open SQL Editor.
3. Run the SQL in `supabase/schema.sql`.
4. Open Project Settings > API and copy the Project URL and anon/public key.
5. Copy `.env.example` to `.env`.
6. Fill in:

```env
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_PUBLIC_KEY
```

7. Restart Expo with cache clear:

```powershell
npx.cmd expo start -c
```

8. In the app, open Backup, create an account or sign in, then choose **Back up this device**.

**Security notes**
- The app uses Supabase Auth and Row Level Security. Each backup row is scoped to `auth.uid()`.
- Only the anon/public key belongs in a client app. Never use the Supabase `service_role` key in a mobile app or commit secrets to Git.
- Enable email confirmation and configure Supabase Auth settings for your deployment.
- Cloud backup is a snapshot of the experiment records. The current implementation does not sync measurement rows, merge concurrent edits, or encrypt payloads end-to-end. Treat the provider as a trusted processor; add client-side encryption and conflict handling before storing sensitive research.
- Restoring replaces the local experiment list. Export important records before restoring.

## Project structure

```text
labledger-pro/
├── app/
│   ├── _layout.tsx
│   ├── index.tsx
│   ├── new-entry.tsx
│   ├── backup.tsx
│   └── entry/[id].tsx
├── src/
│   ├── components/MeasurementChart.tsx
│   ├── db/database.ts
│   ├── db/entries.ts
│   ├── services/cloud.ts
│   ├── services/pdf.ts
│   └── ui.tsx
├── supabase/schema.sql
├── tests/entries.test.ts
├── vitest.config.ts
├── .env.example
└── README.md
```

## Roadmap

- [ ] Measurement data included in cloud snapshots
- [ ] End-to-end encrypted backup
- [ ] Conflict-aware incremental sync
- [ ] Photo attachments
- [ ] CSV export
- [ ] More chart types and units
- [ ] UI and integration test coverage
- [ ] GitHub Actions CI and release builds

## Disclaimer

LabLedger is a record-keeping tool, not a laboratory safety guide or substitute for approved protocols and instructor supervision.

## License

MIT.
