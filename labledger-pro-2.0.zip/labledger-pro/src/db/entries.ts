import type { SQLiteDatabase } from "expo-sqlite";
export type Entry = {
  id: number; title: string; subject: string; objective: string; method: string; observations: string;
  result: string; status: "draft" | "completed"; createdAt: string; updatedAt: string;
};
type EntryRow = Omit<Entry, "createdAt" | "updatedAt"> & { created_at: string; updated_at: string };
export type Measurement = { id: number; entryId: number; label: string; value: number; unit: string; createdAt: string };
type MeasurementRow = { id: number; entry_id: number; label: string; value: number; unit: string; created_at: string };
const mapEntry = (r: EntryRow): Entry => ({ ...r, createdAt: r.created_at, updatedAt: r.updated_at });
const mapMeasurement = (r: MeasurementRow): Measurement => ({ id: r.id, entryId: r.entry_id, label: r.label, value: r.value, unit: r.unit, createdAt: r.created_at });
export async function listEntries(db: SQLiteDatabase): Promise<Entry[]> {
  return (await db.getAllAsync<EntryRow>("SELECT * FROM entries ORDER BY created_at DESC")).map(mapEntry);
}
export async function getEntry(db: SQLiteDatabase, id: number): Promise<Entry | null> {
  const row = await db.getFirstAsync<EntryRow>("SELECT * FROM entries WHERE id = ?", id);
  return row ? mapEntry(row) : null;
}
export async function createEntry(db: SQLiteDatabase, input: Pick<Entry, "title" | "subject" | "objective" | "method" | "observations" | "result">) {
  const now = new Date().toISOString();
  await db.runAsync(`INSERT INTO entries (title, subject, objective, method, observations, result, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    input.title, input.subject, input.objective, input.method, input.observations, input.result, now, now);
}
export async function setEntryStatus(db: SQLiteDatabase, id: number, status: Entry["status"]) {
  await db.runAsync("UPDATE entries SET status = ?, updated_at = ? WHERE id = ?", status, new Date().toISOString(), id);
}
export async function deleteEntry(db: SQLiteDatabase, id: number) { await db.runAsync("DELETE FROM entries WHERE id = ?", id); }
export async function addMeasurement(db: SQLiteDatabase, entryId: number, label: string, value: number, unit: string) {
  await db.runAsync("INSERT INTO measurements (entry_id, label, value, unit, created_at) VALUES (?, ?, ?, ?, ?)", entryId, label, value, unit, new Date().toISOString());
}
export async function listMeasurements(db: SQLiteDatabase, entryId: number): Promise<Measurement[]> {
  return (await db.getAllAsync<MeasurementRow>("SELECT * FROM measurements WHERE entry_id = ? ORDER BY id ASC", entryId)).map(mapMeasurement);
}
export type BackupEntry = Omit<Entry, "id"> & { id?: number };
export async function restoreEntries(db: SQLiteDatabase, entries: BackupEntry[]) {
  await db.withTransactionAsync(async () => {
    await db.runAsync("DELETE FROM entries");
    for (const e of entries) {
      await db.runAsync(
        `INSERT INTO entries (title, subject, objective, method, observations, result, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        e.title, e.subject, e.objective, e.method, e.observations, e.result, e.status, e.createdAt, e.updatedAt
      );
    }
  });
}