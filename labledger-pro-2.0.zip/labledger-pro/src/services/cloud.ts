import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import type { BackupEntry, Entry } from "@/src/db/entries";

let client: SupabaseClient | null | undefined;
export function createClientIfConfigured() {
  if (client !== undefined) return client;
  const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
  const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
  client = url && key ? createClient(url, key, {
    auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false }
  }) : null;
  return client;
}
function requireClient() {
  const c = createClientIfConfigured();
  if (!c) throw new Error("Supabase is not configured. Add the project URL and anon key to .env.");
  return c;
}
async function requireUser() {
  const c = requireClient();
  const { data, error } = await c.auth.getUser();
  if (error || !data.user) throw new Error("Please sign in before using cloud backup.");
  return { c, user: data.user };
}
export async function cloudSignUp(email: string, password: string) {
  if (!email.includes("@") || password.length < 8) throw new Error("Enter a valid email and a password of at least 8 characters.");
  const { error } = await requireClient().auth.signUp({ email, password });
  if (error) throw error;
}
export async function cloudSignIn(email: string, password: string) {
  const { error } = await requireClient().auth.signInWithPassword({ email, password });
  if (error) throw error;
}
export async function uploadBackup(entries: Entry[]) {
  const { c, user } = await requireUser();
  const payload: BackupEntry[] = entries.map(({ id: _id, ...e }) => e);
  const { error } = await c.from("user_backups").upsert({
    user_id: user.id, payload, updated_at: new Date().toISOString()
  }, { onConflict: "user_id" });
  if (error) throw error;
}
export async function downloadBackup(): Promise<BackupEntry[]> {
  const { c, user } = await requireUser();
  const { data, error } = await c.from("user_backups").select("payload").eq("user_id", user.id).single();
  if (error) throw error;
  if (!Array.isArray(data.payload)) throw new Error("Backup data has an unexpected format.");
  return data.payload as BackupEntry[];
}