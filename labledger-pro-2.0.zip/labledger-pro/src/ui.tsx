import type { PropsWithChildren } from "react";
import { Pressable, Text, View, type ViewStyle, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
export function Screen({ children }: PropsWithChildren) { return <SafeAreaView style={styles.screen} edges={["left","right","bottom"]}>{children}</SafeAreaView>; }
export function Card({ children, style }: PropsWithChildren<{ style?: ViewStyle }>) { return <View style={[styles.card, style]}>{children}</View>; }
export function SectionTitle({ children }: PropsWithChildren) { return <Text style={styles.sectionTitle}>{children}</Text>; }
export function EmptyState({ onCreate }: { onCreate: () => void }) {
  return <View style={styles.empty}><View style={styles.emptyIcon}><Ionicons name="beaker-outline" size={30} color="#55D6BE"/></View>
    <Text style={styles.emptyTitle}>Your lab book starts here.</Text><Text style={styles.emptyText}>Create your first experiment record. Your notes stay on this device.</Text>
    <Pressable onPress={onCreate} style={styles.primaryButton}><Text style={styles.primaryButtonText}>Create first entry</Text></Pressable></View>;
}
export const styles = StyleSheet.create({
 screen:{flex:1,backgroundColor:"#0B1220",paddingHorizontal:20,paddingTop:14},topline:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:25},
 eyebrow:{color:"#55D6BE",fontSize:10,letterSpacing:1.5,fontWeight:"800",marginBottom:8},hero:{color:"#F5F7FB",fontSize:34,fontWeight:"900",letterSpacing:-1.4},
 subtle:{color:"#91A0B5",fontSize:13,marginTop:5},avatar:{width:48,height:48,borderRadius:16,backgroundColor:"#17333A",alignItems:"center",justifyContent:"center"},
 statsRow:{flexDirection:"row",gap:12,marginBottom:18},statCard:{flex:1,padding:17},card:{backgroundColor:"#121D2D",borderWidth:1,borderColor:"#233247",borderRadius:19,padding:16,marginBottom:12},
 statNumber:{color:"#F5F7FB",fontSize:28,fontWeight:"800"},statLabel:{color:"#8292A9",fontSize:9,letterSpacing:1.1,marginTop:5,fontWeight:"800"},
 sectionRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:17,marginBottom:12},sectionTitle:{color:"#F5F7FB",fontSize:18,fontWeight:"800"},
 smallAction:{backgroundColor:"#55D6BE",borderRadius:12,paddingHorizontal:13,paddingVertical:9,flexDirection:"row",alignItems:"center",gap:4},
 smallActionText:{color:"#08131D",fontWeight:"800",fontSize:12},entryCard:{marginBottom:11},entryTop:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
 category:{color:"#55D6BE",fontSize:9,letterSpacing:1.2,fontWeight:"800"},status:{borderRadius:20,paddingHorizontal:9,paddingVertical:4},
 statusDone:{backgroundColor:"#153B35"},statusDraft:{backgroundColor:"#3A3020"},statusText:{color:"#C9D7E6",fontSize:9,textTransform:"capitalize"},
 entryTitle:{color:"#F5F7FB",fontSize:17,fontWeight:"800",marginTop:12},entrySummary:{color:"#91A0B5",fontSize:12,lineHeight:18,marginTop:6},
 entryBottom:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginTop:14},date:{color:"#718096",fontSize:10},
 empty:{flex:1,justifyContent:"center",alignItems:"center",paddingHorizontal:16,paddingBottom:80},emptyIcon:{width:70,height:70,borderRadius:23,backgroundColor:"#17333A",alignItems:"center",justifyContent:"center",marginBottom:18},
 emptyTitle:{color:"#F5F7FB",fontSize:19,fontWeight:"800"},emptyText:{color:"#91A0B5",textAlign:"center",lineHeight:20,fontSize:12,marginTop:9,marginBottom:20},
 primaryButton:{backgroundColor:"#55D6BE",borderRadius:14,paddingVertical:15,paddingHorizontal:20,alignItems:"center",marginTop:14},primaryButtonText:{color:"#08131D",fontWeight:"900",fontSize:13},
 formHeading:{color:"#F5F7FB",fontSize:27,fontWeight:"900",marginBottom:22},fieldLabel:{color:"#D9E2EF",fontSize:12,fontWeight:"800",marginTop:17,marginBottom:8},
 input:{backgroundColor:"#121D2D",borderColor:"#2A3A50",borderWidth:1,borderRadius:13,color:"#F5F7FB",paddingHorizontal:14,paddingVertical:13,fontSize:13},
 multiline:{minHeight:95,textAlignVertical:"top"},chips:{flexDirection:"row",flexWrap:"wrap",gap:8,marginBottom:8},chip:{borderWidth:1,borderColor:"#314158",borderRadius:30,paddingVertical:8,paddingHorizontal:12},
 chipSelected:{backgroundColor:"#173D3A",borderColor:"#55D6BE"},chipText:{color:"#AAB7C8",fontSize:11},chipTextSelected:{color:"#8EF0DC",fontWeight:"800"},
 detailTitle:{color:"#F5F7FB",fontSize:29,fontWeight:"900",lineHeight:35,marginBottom:18},detailActions:{flexDirection:"row",gap:8,flexWrap:"wrap",marginBottom:10},
 outlineButton:{borderWidth:1,borderColor:"#55D6BE",borderRadius:12,paddingVertical:11,paddingHorizontal:14,marginTop:8},outlineButtonText:{color:"#8EF0DC",fontWeight:"800",fontSize:11},
 deleteButton:{borderWidth:1,borderColor:"#70404A",borderRadius:12,paddingVertical:11,paddingHorizontal:14,marginTop:8},deleteText:{color:"#F39BA8",fontWeight:"800",fontSize:11},
 detailSection:{borderBottomWidth:1,borderBottomColor:"#233247",paddingBottom:17,marginTop:8},detailBody:{color:"#C1CDDC",fontSize:13,lineHeight:21},
 privacyNote:{color:"#718096",fontSize:10,textAlign:"center",marginTop:24},actionRow:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:12},
 secondaryAction:{borderWidth:1,borderColor:"#365268",borderRadius:12,paddingHorizontal:13,paddingVertical:9,flexDirection:"row",gap:6,alignItems:"center"},secondaryActionText:{color:"#8EF0DC",fontWeight:"800",fontSize:12},
 searchInput:{backgroundColor:"#121D2D",borderColor:"#2A3A50",borderWidth:1,borderRadius:13,color:"#F5F7FB",paddingHorizontal:14,paddingVertical:13,fontSize:13,marginBottom:10},
 resultCount:{color:"#718096",fontSize:11},measureForm:{flexDirection:"row",gap:7,marginTop:12},chartCard:{backgroundColor:"#121D2D",borderColor:"#233247",borderWidth:1,borderRadius:17,padding:12,marginTop:14},
 chartTitle:{color:"#F5F7FB",fontWeight:"800",fontSize:14,marginBottom:8},measureRow:{flexDirection:"row",justifyContent:"space-between",paddingVertical:6,borderTopWidth:1,borderTopColor:"#233247"},
 measureLabel:{color:"#AAB7C8",fontSize:11},measureValue:{color:"#8EF0DC",fontSize:11,fontWeight:"800"},warning:{color:"#F2C879",backgroundColor:"#332B1C",padding:12,borderRadius:12,marginTop:15,lineHeight:19,fontSize:12},
 divider:{height:1,backgroundColor:"#233247",marginVertical:18},statusMessage:{color:"#91A0B5",fontSize:12,lineHeight:19,marginTop:18}
});