import { Text, View } from "react-native";
import Svg, { Circle, Line, Polyline, Text as SvgText } from "react-native-svg";
import type { Measurement } from "@/src/db/entries";
import { styles } from "@/src/ui";

export function MeasurementChart({ measurements }: { measurements: Measurement[] }) {
  const width = 320, height = 190, pad = 30;
  const vals = measurements.map(m => m.value);
  const min = Math.min(...vals), max = Math.max(...vals);
  const range = max - min || 1;
  const points = measurements.map((m, i) => {
    const x = pad + (measurements.length === 1 ? 0 : i * (width - pad * 2) / (measurements.length - 1));
    const y = height - pad - ((m.value - min) / range) * (height - pad * 2);
    return `${x},${y}`;
  }).join(" ");
  return <View style={styles.chartCard}>
    <Text style={styles.chartTitle}>Measurement trend</Text>
    <Svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`}>
      <Line x1={pad} y1={pad} x2={pad} y2={height-pad} stroke="#40516A" strokeWidth="1"/>
      <Line x1={pad} y1={height-pad} x2={width-pad} y2={height-pad} stroke="#40516A" strokeWidth="1"/>
      {measurements.length > 1 && <Polyline points={points} fill="none" stroke="#55D6BE" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round"/>}
      {measurements.map((m, i) => {
        const x = pad + (measurements.length === 1 ? 0 : i * (width - pad * 2) / (measurements.length - 1));
        const y = height - pad - ((m.value - min) / range) * (height - pad * 2);
        return <Circle key={m.id} cx={x} cy={y} r="4.5" fill="#55D6BE"/>;
      })}
      <SvgText x={pad} y={15} fill="#91A0B5" fontSize="10">{max}</SvgText>
      <SvgText x={pad} y={height-5} fill="#91A0B5" fontSize="10">{min}</SvgText>
    </Svg>
    {measurements.map(m => <View key={m.id} style={styles.measureRow}><Text style={styles.measureLabel}>{m.label}</Text><Text style={styles.measureValue}>{m.value} {m.unit}</Text></View>)}
  </View>;
}