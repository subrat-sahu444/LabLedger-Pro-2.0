import { describe, expect, it } from "vitest";

type EntryInput = { title: string; subject: string; objective: string; method: string; observations: string; result: string };
function validateEntry(input: EntryInput) {
  return input.title.trim().length >= 3 && input.title.trim().length <= 100 &&
    input.subject.trim().length > 0 && input.title.length <= 100;
}
describe("experiment input validation", () => {
  const base = { title: "Acid-base titration", subject: "Chemistry", objective: "", method: "", observations: "", result: "" };
  it("accepts a valid experiment", () => expect(validateEntry(base)).toBe(true));
  it("rejects a title that is too short", () => expect(validateEntry({ ...base, title: "  " })).toBe(false));
  it("rejects a title longer than 100 characters", () => expect(validateEntry({ ...base, title: "x".repeat(101) })).toBe(false));
  it("rejects a missing subject", () => expect(validateEntry({ ...base, subject: " " })).toBe(false));
});