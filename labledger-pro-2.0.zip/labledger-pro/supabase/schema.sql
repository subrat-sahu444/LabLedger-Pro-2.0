-- Run this SQL in Supabase Dashboard > SQL Editor.
-- RLS ensures a signed-in user can access only their own backup row.
create table if not exists public.user_backups (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.user_backups enable row level security;

create policy "Users can read their own backup"
on public.user_backups for select
to authenticated
using (auth.uid() = user_id);

create policy "Users can insert their own backup"
on public.user_backups for insert
to authenticated
with check (auth.uid() = user_id);

create policy "Users can update their own backup"
on public.user_backups for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Do not create public/anon policies. Never expose the service_role key in the app.
